// lib/agent/query_processor.dart
//
// This is the central pipeline for the AI agent.
// It wires together: Language Detection → Translation → NLP → DB Search.
//
// Pipeline:
//   raw text (any language)
//     ↓ LanguageDetector.detect()
//     ↓ TranslatorService.translate(→ English)
//     ↓ IntentDetector.detect()
//     ↓ KeywordExtractor.extract()
//     ↓ KnowledgeRepository.findBestMatch()
//     ↓ returns (KnowledgeModel?, NlpResult, detectedLang)

import '../database/knowledge_repository.dart';
import '../language/language_detector.dart';
import '../models/knowledge_model.dart';
import '../nlp/intent_detector.dart';
import '../nlp/keyword_extractor.dart';
import '../translation/translator_service.dart';

class QueryResult {
  final KnowledgeModel? match;
  final NlpResult nlpResult;
  final String detectedLanguage;
  final String translatedQuery;

  const QueryResult({
    required this.match,
    required this.nlpResult,
    required this.detectedLanguage,
    required this.translatedQuery,
  });

  bool get hasAnswer => match != null;
}

class QueryProcessor {
  final LanguageDetector _detector;
  final TranslatorService _translator;
  final IntentDetector _intentDetector;
  final KeywordExtractor _keywordExtractor;
  final KnowledgeRepository _repository;

  QueryProcessor({
    required LanguageDetector detector,
    required TranslatorService translator,
    required IntentDetector intentDetector,
    required KeywordExtractor keywordExtractor,
    required KnowledgeRepository repository,
  })  : _detector = detector,
        _translator = translator,
        _intentDetector = intentDetector,
        _keywordExtractor = keywordExtractor,
        _repository = repository;

  // ──────────────────────────────────────────────
  // Main pipeline
  // ──────────────────────────────────────────────
  Future<QueryResult> process(String userText) async {
    // Step 1 – Detect language
    final detectedLang = await _detector.detect(userText);

    // Step 2 – Translate to English (no-op if already English)
    final englishText = detectedLang == 'en'
        ? userText
        : await _translator.translate(userText, detectedLang, 'en');

    // Step 3 – NLP: intent + keywords
    final intentResult = _intentDetector.detect(englishText);
    final keywords = _keywordExtractor.extract(englishText);
    final category = _intentDetector.intentToCategory(intentResult.intent);

    final nlpResult = NlpResult(
      intent: intentResult.intent,
      keywords: keywords,
      confidence: intentResult.confidence,
    );

    // Step 4 – Database search
    final match = await _repository.findBestMatch(
      keywords: keywords,
      category: category,
    );

    return QueryResult(
      match: match,
      nlpResult: nlpResult,
      detectedLanguage: detectedLang,
      translatedQuery: englishText,
    );
  }
}
