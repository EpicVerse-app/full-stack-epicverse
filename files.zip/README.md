# Offline Multilingual AI Agent — Flutter App

A fully **offline**, **multilingual** voice AI agent for Android and iOS.  
After language packs are downloaded, the app runs entirely on-device — no cloud required.

---

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                         User Interface                          │
│              HomeScreen ← ChatScreen ← LanguageSettings         │
└────────────────────────────┬────────────────────────────────────┘
                             │
                    ┌────────▼────────┐
                    │  Voice / Text   │
                    │     Input       │
                    └────────┬────────┘
                             │
          ┌──────────────────▼──────────────────────┐
          │           SpeechRecognizer              │
          │  (Vosk offline STT · per-language model) │
          └──────────────────┬──────────────────────┘
                             │ raw text (any language)
          ┌──────────────────▼──────────────────────┐
          │           LanguageDetector              │
          │    (ML Kit Language Identification)      │
          └──────────────────┬──────────────────────┘
                             │ detected lang code
          ┌──────────────────▼──────────────────────┐
          │          TranslatorService               │
          │ (ML Kit Translation · lang → English)   │
          └──────────────────┬──────────────────────┘
                             │ English text
          ┌──────────────────▼──────────────────────┐
          │            QueryProcessor                │
          │   IntentDetector + KeywordExtractor      │
          └──────────────────┬──────────────────────┘
                             │ NlpResult { intent, keywords }
          ┌──────────────────▼──────────────────────┐
          │         KnowledgeRepository              │
          │   SQLite FTS5 search on knowledge.db    │
          └──────────────────┬──────────────────────┘
                             │ KnowledgeModel (English answer)
          ┌──────────────────▼──────────────────────┐
          │          ResponseGenerator               │
          │   TranslatorService (English → user lang)│
          └──────────────────┬──────────────────────┘
                             │ localized response text
          ┌──────────────────▼──────────────────────┐
          │         TextToSpeechService              │
          │  (flutter_tts · Android TTS / AVSynth)   │
          └─────────────────────────────────────────┘
```

---

## Project Structure

```
ai_agent_app/
├── lib/
│   ├── main.dart                        # App entry + DI setup
│   ├── ui/
│   │   ├── home_screen.dart             # App shell + header
│   │   ├── chat_screen.dart             # Chat UI + voice button
│   │   └── language_settings.dart       # Language pack manager
│   ├── speech/
│   │   ├── speech_recognizer.dart       # Vosk STT wrapper
│   │   └── microphone_manager.dart      # Permission handling
│   ├── tts/
│   │   └── text_to_speech_service.dart  # flutter_tts wrapper
│   ├── language/
│   │   ├── language_detector.dart       # ML Kit lang detection
│   │   └── language_manager.dart        # Active lang + pack state
│   ├── translation/
│   │   └── translator_service.dart      # Offline translation layer
│   ├── nlp/
│   │   ├── intent_detector.dart         # Rule-based intent classifier
│   │   └── keyword_extractor.dart       # Stopword-filtered extraction
│   ├── agent/
│   │   ├── query_processor.dart         # Pipeline orchestrator
│   │   └── response_generator.dart      # Answer builder + translator
│   ├── database/
│   │   ├── database_helper.dart         # SQLite init + FTS triggers
│   │   └── knowledge_repository.dart    # CRUD + search queries
│   ├── models/
│   │   └── knowledge_model.dart         # Data models
│   ├── downloader/
│   │   └── language_pack_downloader.dart # Download + extract models
│   └── utils/
│       └── config.dart                  # Central configuration
├── assets/
│   └── data/
│       └── seed_knowledge.json          # Bundled knowledge base
├── android/
│   └── app/src/main/AndroidManifest.xml
├── ios/
│   └── Runner/Info.plist
└── pubspec.yaml
```

---

## Database Schema

```sql
-- Primary knowledge table
CREATE TABLE knowledge (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  question_en TEXT    NOT NULL,
  answer_en   TEXT    NOT NULL,
  category    TEXT    NOT NULL DEFAULT 'general',
  keywords    TEXT    NOT NULL DEFAULT ''   -- comma-separated
);

-- FTS5 virtual table for fast full-text search
CREATE VIRTUAL TABLE knowledge_fts USING fts5(
  question_en,
  answer_en,
  keywords,
  content='knowledge',
  content_rowid='id'
);
```

---

## Language Pack Storage Layout

```
<app_documents>/
├── languages/
│   ├── vosk-model-small-en-us-0.15/    # Bundled / always present
│   ├── vosk-model-small-hi-0.22/       # Downloaded on demand
│   ├── vosk-model-small-ta-0.4/
│   ├── vosk-model-small-es-0.42/
│   └── vosk-model-small-fr-0.22/
└── translation_models/
    ├── hi-en.argos
    ├── ta-en.argos
    ├── es-en.argos
    └── fr-en.argos
```

---

## Supported Languages

| Code | Language | Speech Model | Translation |
|------|----------|-------------|-------------|
| `en` | English  | vosk-small-en | Base (no translation) |
| `hi` | Hindi    | vosk-small-hi | hi ↔ en |
| `ta` | Tamil    | vosk-small-ta | ta ↔ en |
| `es` | Spanish  | vosk-small-es | es ↔ en |
| `fr` | French   | vosk-small-fr | fr ↔ en |

---

## Getting Started

### Prerequisites
- Flutter ≥ 3.10.0  
- Android SDK 21+ / iOS 13+  
- Dart ≥ 3.0.0  

### Setup

```bash
# 1. Install dependencies
flutter pub get

# 2. Run code generation (for JSON serialization)
flutter pub run build_runner build --delete-conflicting-outputs

# 3. Run on Android
flutter run -d android

# 4. Run on iOS
flutter run -d ios
```

### First Launch
1. The English language pack is built-in and works offline immediately.
2. Open **Language Settings** (globe icon in the header) to download additional language packs.
3. Each language pack requires an internet connection to download (~50–200 MB), but works fully offline thereafter.

---

## Offline Translation Strategy

Three options are provided (select one at integration time):

| Strategy | Library | Pros | Cons |
|---------|---------|------|------|
| **A** ML Kit (recommended for MVP) | `google_mlkit_translation` | Easy, reliable, ~30MB/lang | Google dependency |
| **B** Argos Translate via dart:ffi | ctranslate2 native lib | Fully open-source | Complex build setup |
| **C** LibreTranslate local server | localhost REST API | Full control | Requires embedded server |

The `TranslatorService` interface abstracts all three — swap the implementation in `TranslatorFactory.create()`.

---

## Adding Knowledge

To expand the knowledge base, add entries to `assets/data/seed_knowledge.json`:

```json
{
  "question_en": "Your question here?",
  "answer_en": "The answer here.",
  "category": "science",
  "keywords": ["keyword1", "keyword2"]
}
```

Or insert directly via `KnowledgeRepository.insert()` at runtime.

---

## Architecture Principles

- **Modular**: Each module (STT, NLP, translation, DB, TTS) is independently testable.
- **Offline-first**: All processing happens on-device after initial pack download.
- **Clean separation**: UI → Agent layer → Service layer → Data layer.
- **Dependency injection**: All services wired via `Provider` in `main.dart`.
- **Extensible**: Add new languages in `AppConfig.supportedLanguages`. Add new intents in `IntentDetector._rules`.
