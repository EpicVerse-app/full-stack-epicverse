// lib/database/database_helper.dart
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../utils/config.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _db;

  Future<Database> get database async {
    _db ??= await _initDatabase();
    return _db!;
  }

  // ──────────────────────────────────────────────
  // Initialization
  // ──────────────────────────────────────────────
  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, AppConfig.dbName);

    return openDatabase(
      path,
      version: AppConfig.dbVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE ${AppConfig.knowledgeTable} (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        question_en TEXT    NOT NULL,
        answer_en   TEXT    NOT NULL,
        category    TEXT    NOT NULL DEFAULT 'general',
        keywords    TEXT    NOT NULL DEFAULT ''
      )
    ''');

    // Full-text search virtual table for fast keyword lookup
    await db.execute('''
      CREATE VIRTUAL TABLE knowledge_fts USING fts5(
        question_en,
        answer_en,
        keywords,
        content='${AppConfig.knowledgeTable}',
        content_rowid='id'
      )
    ''');

    // Triggers to keep FTS in sync
    await db.execute('''
      CREATE TRIGGER knowledge_ai AFTER INSERT ON ${AppConfig.knowledgeTable} BEGIN
        INSERT INTO knowledge_fts(rowid, question_en, answer_en, keywords)
        VALUES (new.id, new.question_en, new.answer_en, new.keywords);
      END
    ''');

    await db.execute('''
      CREATE TRIGGER knowledge_ad AFTER DELETE ON ${AppConfig.knowledgeTable} BEGIN
        INSERT INTO knowledge_fts(knowledge_fts, rowid, question_en, answer_en, keywords)
        VALUES ('delete', old.id, old.question_en, old.answer_en, old.keywords);
      END
    ''');

    await db.execute('''
      CREATE TRIGGER knowledge_au AFTER UPDATE ON ${AppConfig.knowledgeTable} BEGIN
        INSERT INTO knowledge_fts(knowledge_fts, rowid, question_en, answer_en, keywords)
        VALUES ('delete', old.id, old.question_en, old.answer_en, old.keywords);
        INSERT INTO knowledge_fts(rowid, question_en, answer_en, keywords)
        VALUES (new.id, new.question_en, new.answer_en, new.keywords);
      END
    ''');

    // Seed initial knowledge from bundled JSON asset
    await _seedKnowledge(db);
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Future migration logic goes here
  }

  // ──────────────────────────────────────────────
  // Seed bundled knowledge
  // ──────────────────────────────────────────────
  Future<void> _seedKnowledge(Database db) async {
    try {
      final jsonStr =
          await rootBundle.loadString('assets/data/seed_knowledge.json');
      final List<dynamic> items = json.decode(jsonStr) as List<dynamic>;

      final batch = db.batch();
      for (final item in items) {
        batch.insert(AppConfig.knowledgeTable, {
          'question_en': item['question_en'],
          'answer_en': item['answer_en'],
          'category': item['category'] ?? 'general',
          'keywords': (item['keywords'] as List<dynamic>? ?? []).join(','),
        });
      }
      await batch.commit(noResult: true);
    } catch (e) {
      // Asset may not exist in development; that's OK
      print('Seed data not loaded: $e');
    }
  }

  // ──────────────────────────────────────────────
  // Generic helpers
  // ──────────────────────────────────────────────
  Future<int> insert(String table, Map<String, dynamic> row) async {
    final db = await database;
    return db.insert(table, row, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, dynamic>>> query(
    String table, {
    String? where,
    List<dynamic>? whereArgs,
    int? limit,
    String? orderBy,
  }) async {
    final db = await database;
    return db.query(
      table,
      where: where,
      whereArgs: whereArgs,
      limit: limit,
      orderBy: orderBy,
    );
  }

  Future<List<Map<String, dynamic>>> rawQuery(
    String sql, [
    List<dynamic>? args,
  ]) async {
    final db = await database;
    return db.rawQuery(sql, args);
  }

  Future<void> close() async {
    final db = await database;
    await db.close();
    _db = null;
  }
}
