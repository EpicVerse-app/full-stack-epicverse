// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'agent/query_processor.dart';
import 'agent/response_generator.dart';
import 'database/knowledge_repository.dart';
import 'downloader/language_pack_downloader.dart';
import 'language/language_detector.dart';
import 'language/language_manager.dart';
import 'nlp/intent_detector.dart';
import 'nlp/keyword_extractor.dart';
import 'translation/translator_service.dart';
import 'ui/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AgentApp());
}

class AgentApp extends StatelessWidget {
  const AgentApp({super.key});

  @override
  Widget build(BuildContext context) {
    // ─────────────────────────────────────────────
    // Dependency Injection via MultiProvider
    // ─────────────────────────────────────────────
    return MultiProvider(
      providers: [
        // Core state
        ChangeNotifierProvider(create: (_) => LanguageManager()..initialize()),

        // Services (lazy singletons)
        Provider<TranslatorService>(
          create: (_) => TranslatorFactory.create(),
          dispose: (_, s) => s.dispose(),
        ),
        Provider<LanguageDetector>(
          create: (_) => LanguageDetector(),
          dispose: (_, d) => d.dispose(),
        ),
        Provider<KnowledgeRepository>(
          create: (_) => KnowledgeRepository(),
        ),
        Provider<IntentDetector>(create: (_) => IntentDetector()),
        Provider<KeywordExtractor>(create: (_) => KeywordExtractor()),

        // Pipeline components
        ProxyProvider5<
            LanguageDetector,
            TranslatorService,
            IntentDetector,
            KeywordExtractor,
            KnowledgeRepository,
            QueryProcessor>(
          update: (_, det, trans, intent, kw, repo, __) => QueryProcessor(
            detector: det,
            translator: trans,
            intentDetector: intent,
            keywordExtractor: kw,
            repository: repo,
          ),
        ),
        ProxyProvider<TranslatorService, ResponseGenerator>(
          update: (_, trans, __) => ResponseGenerator(translator: trans),
        ),

        // Downloader
        ProxyProvider<LanguageManager, LanguagePackDownloader>(
          update: (_, langManager, __) =>
              LanguagePackDownloader(langManager),
        ),
      ],
      child: MaterialApp(
        title: 'AI Agent',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF3B82F6),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
          fontFamily: 'Roboto',
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
